# miistore
Aplikasi toko online adalah proses transaksi jual beli dan pemesanan secara online. Ini versinya 1.1
<br/><br/>
Ada beberapa fitur front end terdapat dalam aplikasi toko online : <br/>
Pencarian produk berdasarkan kata kunci<br/>
Menampilkan semua produk<br/>
Memilih menu navigasi<br/>
Menampilkan detail produk<br/>
Menambahkan produk ke daftar keranjang belanja<br/>
Mendaftar akun baru dan masuk akun<br/>
Mengubah profil akun<br/>
Melakukan transaksi pembayaran<br/>
Mengkonfirmasikan bukti pembayaran<br/><br/>
Ada beberapa fitur back end terdapat dalam aplikasi toko online :<br/>
Daftar akun baru, reset kata sandi, masuk akun<br/>
Mencatat jumlah pengunjung<br/>
Mengelola data pemesanan<br/>
Mengelola data brand produk<br/>
Mengelola data kategori produk<br/>
Mengelola data subkategori produk<br/>
Mengelola data warna produk<br/>
Mengelola data produk<br/>
Menampilkan laporan data produk<br/>
Menampilkan laporan data produk berdasarkan kategori dan subkategori<br/>
Menampilkan laporan data pemesanan<br/>
Menampilkan laporan data pemesanan berdasarkan tanggal<br/>
Menampilkan daftar kontak pelanggan<br/>
Pemantauan statistik data penjualan per hari<br/>
Pemantauan statistik data penjualan per bulan<br/>
Pemantauan statistik data pemesanan per hari<br/>
Pemantauan statistik data pemesanan per bulan<br/>
Mengubah profil akun<br/><br/>
Dalam perancangan pembuatan aplikasi toko online berbasis web adalah :<br/>
Bahasa front end (HTML, CSS, Javascript, JQuery)<br/>
Bahasa framework CSS (Bootstrap)<br/>
Bahasa back end (PHP dan MySQL)<br/>
Library PHP (ChartJS, PHPExcel)<br/>
Web server XAMPP (Saya menggunakan XAMPP versi 5 sekaligus versi 7.1<br/>
Web browser Mozilla dan Chrome<br/>
OS Windows 8.1<br/>
